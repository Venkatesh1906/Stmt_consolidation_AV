import json
import os.path
import os
import xmltodict
import pandas as pd
from flatten_json import flatten

xml_root = 'm2:M006'
xml_element = 'M005'

def convert_xml_to_csv(xml_file_path, csv_file_path, file_name):
    xml_file = file_name + ".xml"
    with open(os.path.join(xml_file_path, xml_file)) as xml_file:
        data = json.loads(json.dumps(xmltodict.parse(xml_file.read())))
    if xml_element in data[xml_root]:
        dic_flattened = (flatten(d, '.') for d in data[xml_root][xml_element])
        df = pd.DataFrame(dic_flattened)
        print(file_name)
        if not os.path.exists(csv_file_path):
            os.makedirs(csv_file_path)
        df.to_csv(os.path.join(csv_file_path, file_name + ".csv"), index=False)
        print('XML to CSV conversion for the file: {}'.format(file_name + ".xml"))


def consolidate_csv(csv_file_path, consolidated_csv_path, consolidated_csv_file):
    all_filenames = os.listdir(csv_file_path)

    # combine all files in the list
    combined_csv = pd.concat([pd.read_csv(os.path.join(csv_file_path, f)) for f in all_filenames])
    # export to csv
    combined_csv.to_csv(os.path.join(consolidated_csv_path, consolidated_csv_file), index=False, encoding='utf-8-sig')
    print('CSV files are consolidated to {}'.format(os.path.join(consolidated_csv_path, consolidated_csv_file)))


if __name__ == '__main__':
    xml_file_path = r"C:\SourceCode\PyCharmWorkspace\DB\Sarasin\MOV_xml"
    csv_file_path = r"C:\SourceCode\PyCharmWorkspace\DB\Sarasin\MOV_csv"
    consolidated_csv_path = r"C:\SourceCode\PyCharmWorkspace\DB\Sarasin\MOV_consolidated_csv"
    consolidated_csv_file = "consolidated_csv_file.csv"
    for file in os.listdir(xml_file_path):
        file_name = os.path.splitext(file)[0]
        convert_xml_to_csv(xml_file_path, csv_file_path, file_name)

    consolidate_csv(csv_file_path, consolidated_csv_path, consolidated_csv_file)